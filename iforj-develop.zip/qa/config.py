# -*- coding: utf-8 -*
# 七牛支持
ACCESS_KEY = "wmN715-Lo5SC1jYIkuqObCLl1bhZoURTxewUGyq2"
SECRET_KEY = "IXXeA4-Rzu9RB6nkf687UjQt9YCOp1JpWptm0C0y"
BUCKET_NAME = "iforj"
